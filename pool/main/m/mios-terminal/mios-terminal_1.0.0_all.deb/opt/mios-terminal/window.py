from gi.repository import Gtk, Gdk, Gio, Adw
from terminal import MiosTerminal, THEMES

class TerminalWindow(Adw.ApplicationWindow):
    def __init__(self, application):
        super().__init__(application=application, title="miOS-Terminal")
        self.config = application.config_manager
        
        # Add application icon (will integrate with the current icon theme)
        self.set_icon_name("utilities-terminal")
        self.set_default_size(800, 600)
        
        self.toolbar_view = Adw.ToolbarView()
        self.set_content(self.toolbar_view)
        
        self.header = Adw.HeaderBar()
        self.toolbar_view.add_top_bar(self.header)
        
        # New Terminal (Tab) button on the left
        new_tab_btn = Gtk.Button(icon_name="tab-new-symbolic")
        new_tab_btn.set_tooltip_text("Nueva Terminal (Pestaña)")
        new_tab_btn.connect("clicked", lambda b: self.create_tab())
        self.header.pack_start(new_tab_btn)
        
        # Hamburger menu
        menu_model = Gio.Menu()
        
        # Submenu for splitting the current tab
        split_menu = Gio.Menu()
        split_menu.append("Dividir Izquierda/Derecha", "win.split_h")
        split_menu.append("Dividir Arriba/Abajo", "win.split_v")
        menu_model.append_submenu("Dividir Vista Actual", split_menu)
        
        menu_model.append("Preferencias", "app.preferences")
        menu_model.append("Acerca de", "app.about")
        
        menu_btn = Gtk.MenuButton()
        menu_btn.set_icon_name("open-menu-symbolic")
        menu_btn.set_menu_model(menu_model)
        self.header.pack_end(menu_btn)
        
        # Tab View for real tabs
        self.tab_view = Adw.TabView()
        self.tab_bar = Adw.TabBar()
        self.tab_bar.set_view(self.tab_view)
        self.tab_bar.set_autohide(True) # Hide if only 1 tab
        
        self.toolbar_view.add_top_bar(self.tab_bar)
        self.toolbar_view.set_content(self.tab_view)
        
        self.active_terminals = []
        self.last_focused_terminal = None
        
        # Initial tab
        self.create_tab()
        
        # Actions for the window
        split_h_action = Gio.SimpleAction.new("split_h", None)
        split_h_action.connect("activate", lambda a, p: self.split_active_terminal(Gtk.Orientation.HORIZONTAL))
        self.add_action(split_h_action)
        
        split_v_action = Gio.SimpleAction.new("split_v", None)
        split_v_action.connect("activate", lambda a, p: self.split_active_terminal(Gtk.Orientation.VERTICAL))
        self.add_action(split_v_action)

        # Actions for the app
        app = self.get_application()
        if not app.lookup_action("preferences"):
            pref_action = Gio.SimpleAction.new("preferences", None)
            pref_action.connect("activate", self.show_preferences)
            app.add_action(pref_action)
            
            about_action = Gio.SimpleAction.new("about", None)
            about_action.connect("activate", self.show_about)
            app.add_action(about_action)
            
        # Handle tab closing properly
        self.tab_view.connect("close-page", self.on_close_page)

    def on_close_page(self, tab_view, page):
        # We recursively find terminals in this page and remove them from active_terminals
        def find_and_remove_terms(widget):
            if isinstance(widget, MiosTerminal):
                if widget in self.active_terminals:
                    self.active_terminals.remove(widget)
                    # We just kill the VTE process cleanly if possible
                    # but closing the tab will destroy the widget anyway.
            else:
                child = widget.get_first_child()
                while child is not None:
                    find_and_remove_terms(child)
                    child = child.get_next_sibling()
        
        find_and_remove_terms(page.get_child())
        
        if len(self.active_terminals) == 0:
            self.close()
            
        return False # Let the default handler close the page

    def create_tab(self):
        # Creates a new tab with a single terminal
        term = self.create_terminal()
        page = self.tab_view.append(term)
        page.set_title("Terminal")
        page.set_icon(Gio.ThemedIcon(name="utilities-terminal"))
        self.tab_view.set_selected_page(page)

    def create_terminal(self):
        term = MiosTerminal(self.config, self)
        term.set_hexpand(True)
        term.set_vexpand(True)
        self.setup_context_menu(term)
        
        focus_controller = Gtk.EventControllerFocus.new()
        focus_controller.connect("enter", self.on_terminal_focus, term)
        term.vte.add_controller(focus_controller)
        
        self.active_terminals.append(term)
        self.last_focused_terminal = term
        return term

    def on_terminal_focus(self, controller, term):
        self.last_focused_terminal = term

    def setup_context_menu(self, term_widget):
        gesture = Gtk.GestureClick.new()
        gesture.set_button(3)
        gesture.connect("released", self.on_right_click, term_widget)
        term_widget.vte.add_controller(gesture)

    def on_right_click(self, gesture, n_press, x, y, term_widget):
        self.last_focused_terminal = term_widget
        menu = Gtk.PopoverMenu()
        
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_margin_top(8)
        box.set_margin_bottom(8)
        box.set_margin_start(8)
        box.set_margin_end(8)
        
        btn_copy = Gtk.Button(label="Copiar", css_classes=["pill"])
        btn_copy.connect("clicked", lambda b: [term_widget.copy_clipboard(), menu.popdown()])
        box.append(btn_copy)
        
        btn_paste = Gtk.Button(label="Pegar", css_classes=["pill"])
        btn_paste.connect("clicked", lambda b: [term_widget.paste_clipboard(), menu.popdown()])
        box.append(btn_paste)
        
        box.append(Gtk.Separator())
        
        btn_split_h = Gtk.Button(label="Dividir Izquierda/Derecha", css_classes=["pill"])
        btn_split_h.connect("clicked", lambda b: [self.split_active_terminal(Gtk.Orientation.HORIZONTAL), menu.popdown()])
        box.append(btn_split_h)
        
        btn_split_v = Gtk.Button(label="Dividir Arriba/Abajo", css_classes=["pill"])
        btn_split_v.connect("clicked", lambda b: [self.split_active_terminal(Gtk.Orientation.VERTICAL), menu.popdown()])
        box.append(btn_split_v)
        
        menu.set_child(box)
        menu.set_parent(term_widget)
        
        rect = Gdk.Rectangle()
        rect.x = int(x)
        rect.y = int(y)
        rect.width = 1
        rect.height = 1
        menu.set_pointing_to(rect)
        menu.popup()

    def split_active_terminal(self, orientation):
        if not self.last_focused_terminal:
            if self.active_terminals:
                self.last_focused_terminal = self.active_terminals[0]
            else:
                return

        term = self.last_focused_terminal
        parent = term.get_parent()
        
        new_term = self.create_terminal()
        
        paned = Gtk.Paned(orientation=orientation)
        paned.set_hexpand(True)
        paned.set_vexpand(True)
        
        # We need to figure out where the terminal is currently inside the tab page hierarchy
        # and replace it with a paned that contains both the old terminal and the new one.
        
        if type(parent) == Gtk.Paned:
            if parent.get_start_child() == term:
                parent.set_start_child(paned)
            else:
                parent.set_end_child(paned)
        elif isinstance(parent, Adw.TabPage) or type(parent).__name__ == 'TabPage':
            # This is a bit tricky, Adw.TabView pages hold a root widget.
            # But the parent is actually an internal stack or the Adw.TabView directly.
            pass
            
        # Safe replacement logic for GTK4 using insert_before/insert_after if it's a Box,
        # but since we only use Paned inside the TabView page (which is just a container),
        # we can just use the tab_view logic. Wait, a terminal placed in a tab is a direct child of some internal container.
        # Let's get the page that contains this widget:
        page = self.tab_view.get_page(term)
        if page:
            # Term was the direct child of the tab
            page.set_child(paned)
        else:
            # Term was already inside a Paned
            if type(parent) == Gtk.Paned:
                if parent.get_start_child() == term:
                    parent.set_start_child(paned)
                else:
                    parent.set_end_child(paned)

        paned.set_start_child(term)
        paned.set_end_child(new_term)
        
        new_term.vte.grab_focus()

    def remove_terminal(self, term):
        if term in self.active_terminals:
            self.active_terminals.remove(term)
            
        parent = term.get_parent()
        if type(parent) == Gtk.Paned:
            other_child = parent.get_start_child() if parent.get_end_child() == term else parent.get_end_child()
            grandparent = parent.get_parent()
            
            # Detach other_child
            if parent.get_start_child() == other_child:
                parent.set_start_child(None)
            else:
                parent.set_end_child(None)
                
            if type(grandparent) == Gtk.Paned:
                if grandparent.get_start_child() == parent:
                    grandparent.set_start_child(other_child)
                else:
                    grandparent.set_end_child(other_child)
            else:
                # It must be the direct child of a tab page
                page = self.tab_view.get_page(parent)
                if page:
                    page.set_child(other_child)
                    
        else:
            # It was the only terminal in the tab
            page = self.tab_view.get_page(term)
            if page:
                self.tab_view.close_page(page)
            
        if len(self.active_terminals) == 0:
            self.close()
        elif self.last_focused_terminal == term:
            self.last_focused_terminal = self.active_terminals[-1]

    def show_preferences(self, action, param):
        pref_win = Adw.PreferencesWindow(transient_for=self, title="Preferencias")
        
        # Apariencia Page
        page_appearance = Adw.PreferencesPage(title="Apariencia", icon_name="applications-graphics-symbolic")
        pref_win.add(page_appearance)
        
        group_app = Adw.PreferencesGroup(title="Estilos")
        page_appearance.add(group_app)
        
        # Theme Row
        theme_model = Gtk.StringList.new(list(THEMES.keys()))
        theme_row = Adw.ComboRow(title="Tema de Colores", model=theme_model)
        
        current_theme = self.config.get("theme", "miOS Dark")
        try:
            idx = list(THEMES.keys()).index(current_theme)
            theme_row.set_selected(idx)
        except:
            pass
            
        theme_row.connect("notify::selected", self.on_theme_changed)
        group_app.add(theme_row)
        
        # Dark/Light Mode Row (System-wide Adwaita preference)
        mode_model = Gtk.StringList.new(["Predeterminado del Sistema", "Modo Claro", "Modo Oscuro"])
        mode_row = Adw.ComboRow(title="Modo de Ventana", model=mode_model)
        # Assuming current state by checking StyleManager
        style_mgr = Adw.StyleManager.get_default()
        if style_mgr.get_color_scheme() == Adw.ColorScheme.FORCE_LIGHT:
            mode_row.set_selected(1)
        elif style_mgr.get_color_scheme() == Adw.ColorScheme.FORCE_DARK:
            mode_row.set_selected(2)
        else:
            mode_row.set_selected(0)
            
        mode_row.connect("notify::selected", self.on_mode_changed)
        group_app.add(mode_row)
        
        font_row = Adw.EntryRow(title="Fuente (Ej: JetBrains Mono 11)")
        font_row.set_text(self.config.get("font", "JetBrains Mono 11"))
        font_row.connect("changed", self.on_font_changed)
        group_app.add(font_row)
        
        # Atajos Page
        page_shortcuts = Adw.PreferencesPage(title="Atajos", icon_name="preferences-desktop-keyboard-shortcuts-symbolic")
        pref_win.add(page_shortcuts)
        
        group_shortcuts = Adw.PreferencesGroup(title="Personalización de Teclado", description="Próximamente podrás editar tus atajos aquí.")
        page_shortcuts.add(group_shortcuts)
        
        # Placeholder for shortcuts
        row_copy = Adw.ActionRow(title="Copiar")
        row_copy.add_suffix(Gtk.Label(label="Ctrl+Shift+C"))
        group_shortcuts.add(row_copy)
        
        row_paste = Adw.ActionRow(title="Pegar")
        row_paste.add_suffix(Gtk.Label(label="Ctrl+Shift+V"))
        group_shortcuts.add(row_paste)
        
        pref_win.present()
        
    def on_mode_changed(self, row, pspec):
        idx = row.get_selected()
        style_mgr = Adw.StyleManager.get_default()
        if idx == 1:
            style_mgr.set_color_scheme(Adw.ColorScheme.FORCE_LIGHT)
        elif idx == 2:
            style_mgr.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        else:
            style_mgr.set_color_scheme(Adw.ColorScheme.DEFAULT)

    def show_about(self, action, param):
        about = Adw.AboutWindow(
            transient_for=self,
            application_name="miOS-Terminal",
            application_icon="utilities-terminal",
            developer_name="Miguel",
            version="1.0.0",
            website="https://github.com/tu-usuario/mios-terminal",
            issue_url="https://github.com/tu-usuario/mios-terminal/issues",
            copyright="© 2026 Miguel",
            license_type=Gtk.License.GPL_3_0
        )
        about.present()
        
    def on_theme_changed(self, row, pspec):
        theme_name = row.get_selected_item().get_string()
        self.config.set("theme", theme_name)
        for term in self.active_terminals:
            term.apply_theme(theme_name)
            
    def on_font_changed(self, row):
        font = row.get_text()
        self.config.set("font", font)
        import gi
        gi.require_version('Pango', '1.0')
        from gi.repository import Pango
        font_desc = Pango.FontDescription.from_string(font)
        for term in self.active_terminals:
            term.vte.set_font(font_desc)
