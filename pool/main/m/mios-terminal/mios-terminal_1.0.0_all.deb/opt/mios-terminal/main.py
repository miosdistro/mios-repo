#!/usr/bin/env python3
import os
import sys
import gi

# Suppress annoying GTK/CSS warnings from the system theme (Canaima/Debian)
os.environ["GTK_A11Y"] = "none"

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
gi.require_version('Vte', '3.91')
gi.require_version('GLib', '2.0')

from gi.repository import Gtk, Gio, Adw
from window import TerminalWindow
from config import ConfigManager

class MiOSTerminalApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id='com.mios.terminal', flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.config_manager = ConfigManager()

    def do_startup(self):
        Adw.Application.do_startup(self)
        
        # Load custom CSS
        css_provider = Gtk.CssProvider()
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            css_provider.load_from_path(os.path.join(script_dir, "style.css"))
            Gtk.StyleContext.add_provider_for_display(
                Gdk.Display.get_default(),
                css_provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )
        except Exception as e:
            pass # We might not have a display yet or file is missing, handled later if needed

    def do_activate(self):
        win = self.props.active_window
        if not win:
            win = TerminalWindow(application=self)
            
            # Apply initial theme
            theme = self.config_manager.get("theme", "Material You")
            self.apply_theme(theme)
            
        win.present()

    def apply_theme(self, theme_name):
        style_manager = Adw.StyleManager.get_default()
        if theme_name == "Material You":
            style_manager.set_color_scheme(Adw.ColorScheme.PREFER_LIGHT) # Default, can be adjusted
        elif theme_name == "Dracula":
            style_manager.set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        # More themes handled in terminal level, here we just set base UI scheme

def main():
    # Make sure we import Gdk later to not fail before GI versioning
    global Gdk
    from gi.repository import Gdk
    
    app = MiOSTerminalApp()
    return app.run(sys.argv)

if __name__ == '__main__':
    sys.exit(main())
