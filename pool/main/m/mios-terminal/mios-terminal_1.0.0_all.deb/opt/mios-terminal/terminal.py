import os
from gi.repository import Gtk, Gdk, GLib, Vte, Pango

THEMES = {
    "Dracula": {
        "bg": "#282a36", "fg": "#f8f8f2",
        "palette": ["#21222c", "#ff5555", "#50fa7b", "#f1fa8c", "#bd93f9", "#ff79c6", "#8be9fd", "#f8f8f2",
                    "#6272a4", "#ff6e6e", "#69ff94", "#ffffa5", "#d6acff", "#ff92df", "#a4ffff", "#ffffff"]
    },
    "Solarized": {
        "bg": "#002b36", "fg": "#839496",
        "palette": ["#073642", "#dc322f", "#859900", "#b58900", "#268bd2", "#d33682", "#2aa198", "#eee8d5",
                    "#002b36", "#cb4b16", "#586e75", "#657b83", "#839496", "#6c71c4", "#93a1a1", "#fdf6e3"]
    },
    "Tango": {
        "bg": "#2e3436", "fg": "#d3d7cf",
        "palette": ["#2e3436", "#cc0000", "#4e9a06", "#c4a000", "#3465a4", "#75507b", "#06989a", "#d3d7cf",
                    "#555753", "#ef2929", "#8ae234", "#fce94f", "#729fcf", "#ad7fa8", "#34e2e2", "#eeeeec"]
    },
    "miOS Dark": {
        "bg": "#11111b", "fg": "#cdd6f4",
        "palette": ["#45475a", "#f38ba8", "#a6e3a1", "#f9e2af", "#89b4fa", "#f5c2e7", "#94e2d5", "#bac2de",
                    "#585b70", "#f38ba8", "#a6e3a1", "#f9e2af", "#89b4fa", "#f5c2e7", "#94e2d5", "#a6adc8"]
    }
}

class MiosTerminal(Gtk.Box):
    def __init__(self, config_manager, parent_window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.config = config_manager
        self.parent_window = parent_window
        
        self.vte = Vte.Terminal()
        self.vte.set_scroll_on_output(True)
        self.vte.set_scroll_on_keystroke(True)
        self.vte.set_mouse_autohide(True)
        
        # Appearance
        font_desc = Pango.FontDescription.from_string(self.config.get("font", "JetBrains Mono 11"))
        self.vte.set_font(font_desc)
        
        self.apply_theme(self.config.get("theme", "miOS Dark"))
        
        # Spawn shell
        shell = os.environ.get("SHELL", "/bin/bash")
        self.vte.spawn_async(
            Vte.PtyFlags.DEFAULT,
            os.environ.get("HOME", "/"),
            [shell],
            None,
            GLib.SpawnFlags.DEFAULT,
            None, None, -1, None, None
        )
        
        # Set up a scrolled window so it can scroll
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(self.vte)
        scroll.set_vexpand(True)
        scroll.set_hexpand(True)
        
        self.append(scroll)
        
        # Signals
        self.vte.connect("child-exited", self.on_child_exited)
        
        # AI/Autosuggestions mock overlay (in a real scenario, we'd use a GTK Popover or interact with bash/fish directly)
        # To truly provide the requested autocomplete, using `fish` or `ble.sh` for bash in the terminal is the native way.
        # However, we can inject a script or recommend setting fish as default.

    def apply_theme(self, theme_name):
        if theme_name not in THEMES:
            theme_name = "miOS Dark"
            
        theme = THEMES[theme_name]
        
        bg_rgba = Gdk.RGBA()
        bg_rgba.parse(theme["bg"])
        
        fg_rgba = Gdk.RGBA()
        fg_rgba.parse(theme["fg"])
        
        palette = []
        for color_str in theme["palette"]:
            rgba = Gdk.RGBA()
            rgba.parse(color_str)
            palette.append(rgba)
            
        self.vte.set_colors(fg_rgba, bg_rgba, palette)

    def on_child_exited(self, terminal, status):
        # We need to inform the parent window to close this tab or view
        self.parent_window.remove_terminal(self)
        
    def copy_clipboard(self):
        self.vte.copy_clipboard_format(Vte.Format.TEXT)
        
    def paste_clipboard(self):
        self.vte.paste_clipboard()
